<script setup>
import WelcomeItem from './WelcomeItem.vue'
</script>

<template>
  <WelcomeItem>
    <template #icon>
    </template>
    <template #heading></template>
  </WelcomeItem>

</template>
